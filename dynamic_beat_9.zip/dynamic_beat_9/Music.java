package dynamic_beat_9;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

import javazoom.jl.player.Player;

public class Music extends Thread {
	
	private Player player; 
	private boolean isLoop; //무한반복인가?
	private File file;
	private FileInputStream fis;
	private BufferedInputStream bis;
	
	public Music(String name, boolean isLoop) {
		
		try {
			this.isLoop=isLoop;
			file=new File(Main.class.getResource("../music/"+name).toURI()); //파일 가져오기
			fis=new FileInputStream(file); 
			bis=new BufferedInputStream(fis); //파일을 버퍼에 담아 읽어오기
			player=new Player(bis); //파일을 담는 플레이어
			
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public int getTime() { //실행되는 음악의 위치
		if (player==null)
			return 0;
		return player.getPosition();
	}
	
	public void close() { //음악 종료
		isLoop=false;
		player.close();
		this.interrupt(); //쓰레드 중지
	}
	
	@Override
	public void run() { //쓰레드를 상속받으면 무조건 써야 하는 함수
		try {
			do {
				player.play(); //곡 실행
				fis=new FileInputStream(file); 
				bis=new BufferedInputStream(fis); //파일을 버퍼에 담아 읽어오기
				player=new Player(bis); //파일을 담는 플레이어
			} while (isLoop);
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

