package dynamic_beat_9;

public class Main {
	
	public static final int SCREEN_WIDTH=1200;
	public static final int SCREEN_HEIGHT=720;
	//public static-모든 프로젝트에서 공유하는 변수
	//final-상수
	
	public static void main(String[] args) {

		new DynamicBeat(); //인스턴스 객체 생성
	}

}



