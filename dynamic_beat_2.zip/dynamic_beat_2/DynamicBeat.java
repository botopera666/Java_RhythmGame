package dynamic_beat_2;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class DynamicBeat extends JFrame{
	
	private Image screenImage;
	private Graphics screenGraphic;
	//더블버퍼링을 위해 전체 화면에 대한 이미지를 담음
	
	private Image IntroBackground; //이미지를 담는 객체
	
	//Ctrl+Shift+O
	
	public DynamicBeat() { 
		setTitle("Dynamic Beat");
		setSize(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
		setResizable(false); //게임 창 사이즈는 고정
		setLocationRelativeTo(null); //실행 시 게임창이 컴퓨터 정중앙
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //종료 시 프로그램 전체 종료
		setVisible(true); //정상 출력되도록-기본값 false
		
		IntroBackground=new ImageIcon(Main.class.
				getResource("../images/IntroBackground.jpg")).getImage();
		//Main 클래스의 위치를 기반으로 이미지파일을 얻어 이미지 인스턴스로 객체 초기화
	}
	
	public void paint(Graphics g) {
		screenImage=createImage(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT); //이미지 생성
		screenGraphic=screenImage.getGraphics();
		screenDraw(screenGraphic); //그림을 그림
		g.drawImage(screenImage, 0, 0, null); //스크린 이미지가 그려짐
	}
	
	public void screenDraw(Graphics g) {
		g.drawImage(IntroBackground, 0, 0, null); //0, 0 위치
		this.repaint();
	}
}


/*배경화면은 디자인하거나, 가져오거나
 * 1280 x 720
 * Introbackground.jpg
 * 이미지를 화면에 띄우는 방식은 버퍼링이 심함
 * 더블버퍼링 기법 이용
 * 버퍼에 이미지를 담아 매 순간마다 이미지를 갱신
 * 
 */