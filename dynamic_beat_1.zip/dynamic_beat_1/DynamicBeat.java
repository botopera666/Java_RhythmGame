package dynamic_beat_1;

import javax.swing.JFrame;

public class DynamicBeat extends JFrame{
	
	public DynamicBeat() {
		setTitle("Dynamic Beat");
		setSize(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
		setResizable(false); //게임 창 사이즈는 고정
		setLocationRelativeTo(null); //실행 시 게임창이 컴퓨터 정중앙
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //종료 시 프로그램 전체 종료
		setVisible(true); //정상 출력되도록-기본값 false
	}
}

/*
 * JFrame- 자바에서 GUI 기반의 프로그램을 만들기 위해 기본적으로 상속
 *이미 존재하는 클래스를 상속받음
 *jFrame을 클래스로 등록해야 setTitle()을 쓸 수 있음-
 *임포트하려면 Ctrl+Shift+O
 */
