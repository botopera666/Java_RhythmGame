package dynamic_beat_4;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class DynamicBeat extends JFrame{
	
	private Image screenImage;
	private Graphics screenGraphic;
	//더블버퍼링을 위해 전체 화면에 대한 이미지를 담음
	
	//이미지
	private Image IntroBackground=new ImageIcon(Main.class.
			getResource("../images/IntroBackground(Title).jpg")).getImage(); 
	//메뉴바
	private JLabel menuBar=new JLabel(new ImageIcon(Main.class.
			getResource("../images/menuBar.png")));
	
	//베이직 아이콘
	private ImageIcon exitButtonBasicImage=new ImageIcon(Main.class.
			getResource("../images/exitButtonBasic.png"));
	//종료 아이콘
	private ImageIcon exitButtonEnteredImage=new ImageIcon(Main.class.
			getResource("../images/exitButtonEntered.png"));
	
	private JButton exitButton=new JButton(exitButtonBasicImage);
	
	private int mouseX, mouseY; //프로그램 안에서 마우스 안의 좌표

	
	//Ctrl+Shift+O
	
	public DynamicBeat() { 
		setUndecorated(true); //실행했을 때 메뉴바가 보이지 않음
		
		setTitle("Dynamic Beat");
		setSize(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
		setResizable(false); //게임 창 사이즈는 고정
		setLocationRelativeTo(null); //실행 시 게임창이 컴퓨터 정중앙
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //종료 시 프로그램 전체 종료
		setVisible(true); //정상 출력되도록-기본값 false
		
		setBackground(new Color(0, 0, 0, 0)); //white
		setLayout(null);
		
		//나가기 버튼
		exitButton.setBounds(1245, 0, 30, 30); //메뉴바의 오른쪽
		exitButton.setBorderPainted(false);
		exitButton.setContentAreaFilled(false);
		exitButton.setFocusPainted(false);
		exitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				exitButton.setIcon(exitButtonEnteredImage); //마우스가 올라가면 이미지를 바꿈
				exitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
				Music buttonEnteredMusic=new Music("buttonEnteredMusic.mp3", false);
				buttonEnteredMusic.start();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				exitButton.setIcon(exitButtonBasicImage); //마우스가 내려감
				exitButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
			@Override
			public void mousePressed(MouseEvent e) {
				Music buttonPressedMusic=new Music("buttonPressedMusic.mp3", false);
				buttonPressedMusic.start();
				//지연 시간으로 소리가 나오도록 함
				try {
					Thread.sleep(1000);
				}
				catch (InterruptedException ex) {
					ex.printStackTrace();
				}
				System.exit(0); //누르면 종료
			}
		});
		add(exitButton);
		//메뉴바 위에 오도록 순서 조정
		
		//메뉴바
		menuBar.setBounds(0, 0, 1280, 30); //위치, 크기 정하기
		menuBar.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				mouseX=e.getX();
				mouseY=e.getY();
			}
		});
		menuBar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x=e.getXOnScreen();
				int y=e.getYOnScreen();
				setLocation(x-mouseX, y-mouseY); //게임창의 위치 바꾸기
			}
		});
		add(menuBar); //JFrame에 메뉴바 추가
		
		//음악
		Music introMusic=new Music("IntroMusic.mp3", true); //시작 화면에서 음악 무한반복
		introMusic.start();
	}
	
	
	
	public void paint(Graphics g) {
		screenImage=createImage(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT); //이미지 생성
		screenGraphic=screenImage.getGraphics();
		screenDraw(screenGraphic); //그림을 그림
		g.drawImage(screenImage, 0, 0, null); //스크린 이미지가 그려짐
	}
	
	
	
	public void screenDraw(Graphics g) {
		g.drawImage(IntroBackground, 0, 0, null); //0, 0 위치
		paintComponents(g); //메뉴바는 항상 존재하는 이미지이고 고정되어 있음
		this.repaint();
	}
}


/*메뉴바 만들기
 * png 파일
 * 
 * 띄어쓰기 정리-Ctrl+Shift+F
 */
 